#!/data/data/com.termux/files/usr/bin/bash

# ============================================================
# CDM TECH / DARKSEID — TERMUX BANNER
# Installation automatique des dépendances
# Bannière propre + mode persistant + styles
# ============================================================

RESET='\033[0m'
CYAN='\033[1;36m'
GREEN='\033[1;32m'
RED='\033[1;31m'
YELLOW='\033[1;33m'
BLUE='\033[1;34m'
MAGENTA='\033[1;35m'
WHITE='\033[1;37m'
DIM='\033[2m'

BANNER_FILE="$HOME/.cdm_tech_banner.sh"
BASHRC="$HOME/.bashrc"

clear_screen() {
    clear 2>/dev/null || printf '\033c'
}

command_exists() {
    command -v "$1" >/dev/null 2>&1
}

install_deps() {
    echo -e "${CYAN}╔════════════════════════════════════════════╗${RESET}"
    echo -e "${CYAN}║       ⚙️  INSTALLATION CDM TECH           ║${RESET}"
    echo -e "${CYAN}╚════════════════════════════════════════════╝${RESET}"

    if ! command_exists pkg; then
        echo -e "${RED}[✗] Ce script doit être exécuté dans Termux.${RESET}"
        exit 1
    fi

    if ! command_exists figlet; then
        echo -e "${YELLOW}[+] Installation automatique de figlet...${RESET}"
        pkg update -y >/dev/null 2>&1
        pkg install figlet -y
    fi

    if command_exists pkg; then
        # Utilitaires de base généralement disponibles dans Termux.
        command_exists sed || pkg install sed -y
    fi

    echo -e "${GREEN}[✓] Dépendances vérifiées.${RESET}"
    echo
}

print_header() {
    echo -e "${RED}╔══════════════════════════════════════════════════╗${RESET}"
    echo -e "${RED}║              ⚡ CDM TECH ⚡                       ║${RESET}"
    echo -e "${RED}║                 DARKSEID                          ║${RESET}"
    echo -e "${RED}╚══════════════════════════════════════════════════╝${RESET}"
}

print_banner() {
    local name="${1:-CDM TECH}"
    local style="${2:-1}"
    local c="$RED"

    clear_screen
    print_header
    echo

    case "$style" in
        1)  c="$RED";     figlet -f standard "$name" ;;
        2)  c="$MAGENTA"; figlet -f slant "$name" ;;
        3)  c="$CYAN";    figlet -f small "$name" ;;
        4)  c="$RED";     figlet -f big "$name" ;;
        5)  c="$YELLOW";  figlet -f block "$name" 2>/dev/null || figlet "$name" ;;
        6)  c="$BLUE";    figlet -f digital "$name" 2>/dev/null || figlet "$name" ;;
        7)  c="$GREEN";   figlet -f bubble "$name" 2>/dev/null || figlet "$name" ;;
        8)  c="$RED";     figlet -f script "$name" 2>/dev/null || figlet "$name" ;;
        9)  c="$CYAN";    figlet -f lean "$name" 2>/dev/null || figlet "$name" ;;
        10) c="$MAGENTA"; figlet -f mini "$name" 2>/dev/null || figlet "$name" ;;
        11) c="$YELLOW";  figlet -f banner "$name" 2>/dev/null || figlet "$name" ;;
        12) c="$BLUE";    figlet -f ivrit "$name" 2>/dev/null || figlet "$name" ;;
        13) c="$GREEN";   figlet -f term "$name" 2>/dev/null || figlet "$name" ;;
        14) c="$RED";     figlet -f cyberlarge "$name" 2>/dev/null || figlet -f standard "$name" ;;
        15) c="$CYAN";    figlet -f future "$name" 2>/dev/null || figlet -f standard "$name" ;;
        16) c="$MAGENTA"; figlet -f dotmatrix "$name" 2>/dev/null || figlet -f standard "$name" ;;
        17) c="$YELLOW";  figlet -f smslant "$name" 2>/dev/null || figlet -f slant "$name" ;;
        18) c="$GREEN";   figlet -f shadow "$name" 2>/dev/null || figlet -f standard "$name" ;;
        19) c="$RED";     figlet -f digital "$name" 2>/dev/null || figlet -f standard "$name" ;;
        20) c="$CYAN";    figlet -f small "$name" ;;
        *)  c="$WHITE";   figlet "$name" ;;
    esac

    echo -e "${c}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo -e "${DIM}        ⚡ CDM TECH • DARKSEID • TERMUX ⚡${RESET}"
    echo -e "${c}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
}

print_custom() {
    clear_screen
    print_header
    echo
    printf '%b%s%b\n' "$MAGENTA" "$SCM_CUSTOM_TEXT" "$RESET"
    echo -e "${RED}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo -e "${DIM}        ⚡ CDM TECH • DARKSEID • TERMUX ⚡${RESET}"
    echo -e "${RED}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
}

random_banner() {
    local n=$((RANDOM % 20 + 1))
    print_banner "${1:-CDM TECH}" "$n"
}

save_config() {
    local name="$1"
    local style="$2"

    cat > "$BANNER_FILE" <<EOF
# CDM TECH persistent banner
CDM_BANNER_NAME=$(printf '%q' "$name")
CDM_BANNER_STYLE=$(printf '%q' "$style")
EOF
}

remove_old_block() {
    if [ -f "$BASHRC" ]; then
        sed -i '/# >>> CDM TECH BANNER >>>/,/# <<< CDM TECH BANNER <<</d' "$BASHRC"
        sed -i '/# >>> SCM TECH BANNER >>>/,/# <<< SCM TECH BANNER <<</d' "$BASHRC"
    fi
}

activate_persistent() {
    local name="$1"
    local style="$2"

    save_config "$name" "$style"
    remove_old_block

    cat >> "$BASHRC" <<'EOF'

# >>> CDM TECH BANNER >>>
if [ -n "$PS1" ] && [ -f "$HOME/.cdm_tech_banner.sh" ]; then
    . "$HOME/.cdm_tech_banner.sh"
    clear 2>/dev/null
    print_banner "$CDM_BANNER_NAME" "$CDM_BANNER_STYLE"
fi
# <<< CDM TECH BANNER <<<
EOF

    echo -e "${GREEN}[✓] Bannière CDM TECH activée au démarrage de Termux.${RESET}"
}

deactivate_persistent() {
    remove_old_block
    rm -f "$BANNER_FILE"
    echo -e "${YELLOW}[!] Bannière persistante désactivée.${RESET}"
}

custom_banner() {
    clear_screen
    print_header
    echo
    echo -e "${WHITE}Entre ton texte ligne par ligne.${RESET}"
    echo -e "${DIM}Tape END seul sur une ligne pour terminer.${RESET}"
    echo

    local text=""
    while IFS= read -r line; do
        [ "$line" = "END" ] && break
        text+="$line"$'\n'
    done

    if [ -z "$text" ]; then
        echo -e "${RED}Aucun texte.${RESET}"
        read -r -p "Entrée..."
        return
    fi

    echo
    echo -e "${GREEN}Aperçu :${RESET}"
    printf '%b%s%b\n' "$MAGENTA" "$text" "$RESET"
    echo

    read -r -p "Nom de cette bannière : " cname
    cname="${cname:-CDM CUSTOM}"

    echo
    echo -e "${YELLOW}[1] Activer au démarrage"
    echo -e "[2] Afficher seulement maintenant"
    echo -e "[0] Retour${RESET}"
    read -r -p "Choix : " choice

    case "$choice" in
        1)
            cat > "$BANNER_FILE" <<EOF
CDM_BANNER_NAME=$(printf '%q' "$cname")
CDM_BANNER_STYLE=custom
SCM_CUSTOM_TEXT=$(printf '%q' "$text")
EOF
            remove_old_block
            cat >> "$BASHRC" <<'EOF'

# >>> CDM TECH BANNER >>>
if [ -n "$PS1" ] && [ -f "$HOME/.cdm_tech_banner.sh" ]; then
    . "$HOME/.cdm_tech_banner.sh"
    clear 2>/dev/null
    if [ "$CDM_BANNER_STYLE" = "custom" ]; then
        print_custom
    else
        print_banner "$CDM_BANNER_NAME" "$CDM_BANNER_STYLE"
    fi
fi
# <<< CDM TECH BANNER <<<
EOF
            echo -e "${GREEN}[✓] Bannière personnalisée activée.${RESET}"
            ;;
        2)
            clear_screen
            print_header
            echo
            printf '%b%s%b\n' "$MAGENTA" "$text" "$RESET"
            ;;
        *) ;;
    esac

    echo
    read -r -p "Entrée pour continuer..."
}

show_styles() {
    clear_screen
    echo -e "${RED}══════════════ APERÇU DES 20 STYLES ══════════════${RESET}"

    local i
    for i in $(seq 1 20); do
        echo -e "\n${YELLOW}[$i]${RESET}"
        case "$i" in
            1) figlet -f standard "CDM TECH" ;;
            2) figlet -f slant "CDM TECH" ;;
            3) figlet -f small "CDM TECH" ;;
            4) figlet -f big "CDM TECH" ;;
            5) figlet -f block "CDM TECH" 2>/dev/null || figlet "CDM TECH" ;;
            6) figlet -f digital "CDM TECH" 2>/dev/null || figlet "CDM TECH" ;;
            7) figlet -f bubble "CDM TECH" 2>/dev/null || figlet "CDM TECH" ;;
            8) figlet -f script "CDM TECH" 2>/dev/null || figlet "CDM TECH" ;;
            9) figlet -f lean "CDM TECH" 2>/dev/null || figlet "CDM TECH" ;;
            10) figlet -f mini "CDM TECH" 2>/dev/null || figlet "CDM TECH" ;;
            11) figlet -f banner "CDM TECH" 2>/dev/null || figlet "CDM TECH" ;;
            12) figlet -f ivrit "CDM TECH" 2>/dev/null || figlet "CDM TECH" ;;
            13) figlet -f term "CDM TECH" 2>/dev/null || figlet "CDM TECH" ;;
            14) figlet -f cyberlarge "CDM TECH" 2>/dev/null || figlet "CDM TECH" ;;
            15) figlet -f future "CDM TECH" 2>/dev/null || figlet "CDM TECH" ;;
            16) figlet -f dotmatrix "CDM TECH" 2>/dev/null || figlet "CDM TECH" ;;
            17) figlet -f smslant "CDM TECH" 2>/dev/null || figlet -f slant "CDM TECH" ;;
            18) figlet -f shadow "CDM TECH" 2>/dev/null || figlet "CDM TECH" ;;
            19) figlet -f digital "CDM TECH" 2>/dev/null || figlet "CDM TECH" ;;
            20) figlet -f small "CDM TECH" ;;
        esac
    done

    read -r -p "Entrée pour revenir au menu..."
}

menu() {
    install_deps

    while true; do
        clear_screen
        echo -e "${RED}╔══════════════════════════════════════════════════╗${RESET}"
        echo -e "${RED}║              ⚡ CDM TECH ⚡                       ║${RESET}"
        echo -e "${RED}║                 DARKSEID                          ║${RESET}"
        echo -e "${RED}╠══════════════════════════════════════════════════╣${RESET}"
        echo -e "${WHITE}║  [1]  DARKSEID                                  ║${RESET}"
        echo -e "${WHITE}║  [2]  CDM TECH                                  ║${RESET}"
        echo -e "${WHITE}║  [3]  CYBER TECH                                ║${RESET}"
        echo -e "${WHITE}║  [4]  HACKER MODE                               ║${RESET}"
        echo -e "${WHITE}║  [5]  TERMINAL KING                             ║${RESET}"
        echo -e "${WHITE}║  [6]  DARK TECH                                 ║${RESET}"
        echo -e "${WHITE}║  [7]  CDM XMD                                   ║${RESET}"
        echo -e "${WHITE}║  [8]  CDM DEV                                   ║${RESET}"
        echo -e "${WHITE}║  [9]  CDM SECURITY                              ║${RESET}"
        echo -e "${WHITE}║  [10] CDM BOSS                                  ║${RESET}"
        echo -e "${WHITE}║  [11] RANDOM                                    ║${RESET}"
        echo -e "${WHITE}║  [12] CHANGER LE NOM                            ║${RESET}"
        echo -e "${WHITE}║  [13] CRÉER MA PROPRE BANNIÈRE                  ║${RESET}"
        echo -e "${WHITE}║  [14] VOIR LES 20 STYLES                        ║${RESET}"
        echo -e "${WHITE}║  [15] ACTIVER AU DÉMARRAGE DE TERMUX            ║${RESET}"
        echo -e "${WHITE}║  [16] DÉSACTIVER LE MODE PERSISTANT             ║${RESET}"
        echo -e "${RED}║  [0]  EXIT                                      ║${RESET}"
        echo -e "${RED}╚══════════════════════════════════════════════════╝${RESET}"
        echo

        read -r -p "CDM-TECH > " choice

        case "$choice" in
            1) print_banner "DARKSEID" 14 ;;
            2) print_banner "CDM TECH" 14 ;;
            3) print_banner "CYBER TECH" 7 ;;
            4) print_banner "HACKER MODE" 6 ;;
            5) print_banner "TERMINAL KING" 18 ;;
            6) print_banner "DARK TECH" 16 ;;
            7) print_banner "CDM XMD" 15 ;;
            8) print_banner "CDM DEV" 9 ;;
            9) print_banner "CDM SECURITY" 3 ;;
            10) print_banner "CDM BOSS" 5 ;;
            11) random_banner "CDM TECH" ;;
            12)
                read -r -p "Nouveau nom : " newname
                newname="${newname:-CDM TECH}"
                read -r -p "Style (1-20) : " newstyle
                newstyle="${newstyle:-14}"
                print_banner "$newname" "$newstyle"
                echo
                read -r -p "Activer ce nom/style au démarrage ? [o/N] : " yn
                [[ "$yn" =~ ^[oOyY]$ ]] && activate_persistent "$newname" "$newstyle"
                ;;
            13) custom_banner ;;
            14) show_styles ;;
            15)
                read -r -p "Nom de la bannière : " pname
                pname="${pname:-CDM TECH}"
                read -r -p "Style (1-20) : " pstyle
                pstyle="${pstyle:-14}"
                activate_persistent "$pname" "$pstyle"
                ;;
            16) deactivate_persistent ;;
            0)
                echo -e "${GREEN}✓ EXIT — CDM TECH reste configuré si le mode persistant est actif.${RESET}"
                exit 0
                ;;
            *) echo -e "${RED}Choix invalide.${RESET}" ;;
        esac

        echo
        read -r -p "Entrée pour continuer..."
    done
}

menu
